#!/bin/bash

echo "`date -Is` - Instalando boto3"
sudo pip install boto3 
