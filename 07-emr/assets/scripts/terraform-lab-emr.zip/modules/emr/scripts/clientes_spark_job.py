import os
import sys
import boto3
from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

print("Iniciando o script de processamento dos dados: clientes_spark_job")
spark = SparkSession \
    .builder \
    .appName("clientes_spark_job") \
    .config("hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory") \
    .enableHiveSupport() \
    .getOrCreate()

spark.catalog.setCurrentDatabase("dataengdb")

print("Definindo a variavel BUCKET_NAME que vamos utilizar ao longo do codigo")
BUCKET_NAME = ""
s3_client = boto3.client('s3')
response = s3_client.list_buckets()

for bucket in response['Buckets']:
    if bucket['Name'].startswith('dataeng-'):
        BUCKET_NAME = bucket['Name']
        break

print("O bucket que vamos utilizar serah: " + BUCKET_NAME)

print("Obtendo os dados de clientes")
df_clientes = spark.sql("select * from dataengdb.tb_raw_clientes")
df_clientes.show(5)

print("Escrevendo os dados de clientes como parquet no S3")
df_clientes.write.format("parquet").mode("overwrite").save(f"s3://{BUCKET_NAME}/stage/clientes")

print("Finalizando o script de processamento dos dados: clientes_spark_job")

